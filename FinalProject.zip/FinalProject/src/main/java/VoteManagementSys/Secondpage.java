package main.java.VoteManagementSys;


//IMPORT PACKAGES
import javax.swing.JOptionPane;//for showing message
//for connection purposes
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
//to connect with the database
import java.sql.DriverManager;



public class Secondpage extends javax.swing.JFrame {
    // We need to connect the database in mysql library
    /* First thing I did is connecting the database to my compiler by going to the
    "Services" in NetBeans, then add new database. 
    From that, I got the link : 
    jdbc:mysql://localhost:3306/oopdb?zeroDateTimeBehavior=CONVERT_TO_NULL [root on Default schema]
    Then, I deleted until it becomes : jdbc:mysql://localhost:3306/oopdb. 
    I learned this from Youtube Tutorials.
    */
    
    Connection Con = null;
    PreparedStatement pst = null;
    ResultSet Rs = null;
    Statement St = null;
    
    //I assigned some string for connection purpose.
    String url = "jdbc:mysql://localhost:3306/oopdb";
    String user = "root";
    String pass = "";
    
    public Secondpage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ChooseL = new javax.swing.JComboBox<>();
        ButtonL = new javax.swing.JButton();
        NameL = new javax.swing.JTextField();
        PassL = new javax.swing.JPasswordField();
        jPanel3 = new javax.swing.JPanel();
        BackC = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(153, 196, 200));

        jPanel1.setBackground(new java.awt.Color(75, 134, 115));
        jPanel1.setForeground(new java.awt.Color(0, 102, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("BEM SYSTEM");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Password: ");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Name : ");

        ChooseL.setBackground(new java.awt.Color(104, 167, 173));
        ChooseL.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ChooseL.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manager", "Visitor", "Employee" }));
        ChooseL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChooseLActionPerformed(evt);
            }
        });

        ButtonL.setBackground(new java.awt.Color(104, 167, 173));
        ButtonL.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ButtonL.setText("Login");
        ButtonL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonLMouseClicked(evt);
            }
        });
        ButtonL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonLActionPerformed(evt);
            }
        });

        NameL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        NameL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameLActionPerformed(evt);
            }
        });

        PassL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel3.setBackground(new java.awt.Color(75, 134, 115));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        BackC.setBackground(new java.awt.Color(104, 167, 173));
        BackC.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BackC.setText("Back");
        BackC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackCMouseClicked(evt);
            }
        });
        BackC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BackC)
                            .addComponent(ChooseL, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(46, 46, 46)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(PassL, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                    .addComponent(NameL))
                .addGap(18, 18, 18)
                .addComponent(ButtonL)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 35, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(ChooseL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PassL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ButtonL))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BackC, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ChooseLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChooseLActionPerformed
    
    }//GEN-LAST:event_ChooseLActionPerformed

    private void ButtonLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonLMouseClicked
        /*ButtonL is actually Login Button
        If operator; ChooseL is the part where you can choose between Manager, Employee
        or Visitor.
        */
        
        //Index = -1; is if none of the 3 are selected
        if(ChooseL.getSelectedIndex()==-1){
            JOptionPane.showMessageDialog(this,"Select between Manager, Employee, or Visitor!");
        }
        //Index = 0 is for Manager, 1 for Visitor, and 2 for Employee.
        else if (ChooseL.getSelectedIndex()==0){
            //if one of them is empty ; shows "Information incomplete"
            if(NameL.getText().isEmpty()||PassL.getText().isEmpty()){
                JOptionPane.showMessageDialog(this,"Information incomplete!");
            }
            //Setting the Name of manager account and Password.
            else if(NameL.getText().equals("Manager")&&PassL.getText().equals("Password")){
                //If the condition is fulfilled, it will redirect you to the MainPage
                new MainPage().setVisible(true);
                this.dispose();
            }
            /*If the Information is wrong, it gives incorrect input message 
            whilst emptying the name and pass.*/
            else{
                JOptionPane.showMessageDialog(this,"Incorrect input!");
                NameL.setText("");
                PassL.setText("");
            }
        }else if(ChooseL.getSelectedIndex()==1){
            /*This is for the visitor, the visitor must be registered by the Manager first
            Manager will be able to set up the username and password of the visitor.
            */
            String Q = " Select * from vis_tab where VisName='"+
            NameL.getText()+"'and VisPass= '"+PassL.getText() +"'";
            /* String Q = " Select * from ctab where CName='"+
            NameL.getText()+"'and CPass= '"+PassL.getText() +"'";
            */
            try{
                // To connect with the database
                // By using the assigned variables and statement.
                Con = DriverManager.getConnection(url,user,pass);
                St = Con.createStatement();
                Rs = St.executeQuery(Q);
                if(Rs.next()){
                    new Sixthpage(Rs.getInt(1)).setVisible(true);
                    this.dispose();
                }else{
                    JOptionPane.showMessageDialog(this,"Incorrect password or username!");
                }

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }
        }else if(ChooseL.getSelectedIndex()==2){
            //this one is for employee; the employee username and password is already assigned
            if(NameL.getText().isEmpty()||PassL.getText().isEmpty()){
                JOptionPane.showMessageDialog(this,"Information incomplete!");

            }else if(NameL.getText().equals("Employee")&&PassL.getText().equals("Password")){
                new Seventhpage().setVisible(true);//The employee username and pass is also set in here
                //if the condition is correct it will redirect you to the seventhpage
                this.dispose();
            }    
            else{
                JOptionPane.showMessageDialog(this,"Incorrect input!");
                NameL.setText("");//inccorect input reset the text and pass to null
                PassL.setText("");
            }    
    
        }
    }//GEN-LAST:event_ButtonLMouseClicked

    private void ButtonLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonLActionPerformed
        
    }//GEN-LAST:event_ButtonLActionPerformed

    private void NameLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameLActionPerformed
            
    }//GEN-LAST:event_NameLActionPerformed

    private void BackCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackCMouseClicked
        //The back button will redirect you to the first page
        new Firstpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackCMouseClicked

    private void BackCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackCActionPerformed
        
    }//GEN-LAST:event_BackCActionPerformed
    
 
    

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Secondpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackC;
    private javax.swing.JButton ButtonL;
    private javax.swing.JComboBox<String> ChooseL;
    private javax.swing.JTextField NameL;
    private javax.swing.JPasswordField PassL;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
