
package main.java.VoteManagementSys;

//Connection purposes
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
//For showing message
import javax.swing.JOptionPane;
//To be able to use DbUtils
//To use (net) u should include Rs2Xml file first. 
//This is then use to manipulate table
//"www.youtube.com/watch?v=4nvTwvfWt7I"
import net.proteanit.sql.DbUtils; 
import javax.swing.table.DefaultTableModel;

public class Thirdpage extends javax.swing.JFrame {
    //I copied from the page before
    Connection Con = null;
    PreparedStatement pst = null;
    ResultSet Rs = null;
    Statement St = null;
    
    String url = "jdbc:mysql://localhost:3306/oopdb";
    String user = "root";
    String pass = "";
    
    public Thirdpage() {
        initComponents();
        MonthDisplay();
        // calling the MonthDisplay function which is for displaying -
        // - the table content
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        MonthLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Monthtable = new javax.swing.JTable();
        AddMonth = new javax.swing.JButton();
        DeleteMonth = new javax.swing.JButton();
        EditMonth = new javax.swing.JButton();
        BackMonth = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        VARMONTH = new com.toedter.calendar.JMonthChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 196, 200));

        jPanel2.setBackground(new java.awt.Color(75, 134, 115));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("BEM SYSTEM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setText("Month ");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Date : ");

        MonthLabel.setFont(new java.awt.Font("Vivaldi", 1, 36)); // NOI18N
        MonthLabel.setText("Name of Month");

        Monthtable.setAutoCreateRowSorter(true);
        Monthtable.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Monthtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Date"
            }
        ));
        Monthtable.setRowHeight(25);
        Monthtable.setSelectionBackground(new java.awt.Color(75, 134, 115));
        Monthtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MonthtableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Monthtable);

        AddMonth.setBackground(new java.awt.Color(104, 167, 173));
        AddMonth.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AddMonth.setText("Add");
        AddMonth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddMonthMouseClicked(evt);
            }
        });
        AddMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddMonthActionPerformed(evt);
            }
        });

        DeleteMonth.setBackground(new java.awt.Color(104, 167, 173));
        DeleteMonth.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        DeleteMonth.setText("Delete");
        DeleteMonth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteMonthMouseClicked(evt);
            }
        });
        DeleteMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteMonthActionPerformed(evt);
            }
        });

        EditMonth.setBackground(new java.awt.Color(104, 167, 173));
        EditMonth.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EditMonth.setText("Edit");
        EditMonth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EditMonthMouseClicked(evt);
            }
        });
        EditMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditMonthActionPerformed(evt);
            }
        });

        BackMonth.setBackground(new java.awt.Color(104, 167, 173));
        BackMonth.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BackMonth.setText("Back");
        BackMonth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackMonthMouseClicked(evt);
            }
        });
        BackMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackMonthActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(75, 134, 115));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(BackMonth, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                .addComponent(AddMonth, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(DeleteMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(EditMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel3)
                        .addComponent(VARMONTH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(MonthLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(VARMONTH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(MonthLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AddMonth)
                            .addComponent(DeleteMonth)
                            .addComponent(EditMonth))
                        .addGap(18, 18, 18)
                        .addComponent(BackMonth)
                        .addGap(90, 90, 90))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 18, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void AddMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AddMonthActionPerformed

    private void DeleteMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DeleteMonthActionPerformed

    private void EditMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EditMonthActionPerformed

    private void BackMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BackMonthActionPerformed
    
    int MId ;
    Statement St1 = null;
    ResultSet Rs1 = null;
    
    //Function that allows Id to automatically increase
    private void CalculateMonthID()
    {
      try{
          St1 = Con.createStatement();
          Rs1 = St1.executeQuery("Select MAX(MId) from month_tab");
          Rs1.next();
          MId = Rs1.getInt(1)+1; 
          
      }catch(Exception Ex){  
      }
    }
    //Function to display the month
    private void MonthDisplay()
    {
        try{
            //connecting to the month_tab 
            //Displaying the month_tab in the Monthtable on JFrame
            Con=DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            Rs = St.executeQuery("Select * from month_tab ");
            Monthtable.setModel(DbUtils.resultSetToTableModel(Rs)); 
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }
    String m = "";    
    private void MonthString(){
        //Function that is used to getting the Month String from its interger value;
        String Month = String.valueOf(VARMONTH.getMonth()+1);       
        if ("1".equals(Month)){m = "January";}else if("2".equals(Month)){m ="February";}
                else if("3".equals(Month)){m ="March";}else if("4".equals(Month)){m ="April";}
                else if("5".equals(Month)){m ="May";}else if("6".equals(Month)){m ="June";}
                else if("7".equals(Month)){m ="July";}else if("8".equals(Month)){m ="August";}
                else if("9".equals(Month)){m ="September";}else if("10".equals(Month)){m ="October";}
                else if("11".equals(Month)){m ="November";}else if("12".equals(Month)){m ="December";}
                
    }
    private void AddMonthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddMonthMouseClicked
        // Code adding election
        if(MonthLabel.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Error");
        }else{
            try{
                //For the Month 
                //I add 1, because I encountered a problem when I entered a month
                //it shows the month number -1.
                String Month = String.valueOf(VARMONTH.getMonth()+1);
                MonthString();
                //For ID purpose.
                CalculateMonthID();
                //Connecting the data from mysql to java
                
                Con=DriverManager.getConnection(url,user,pass);
                //Inserting data to mysql
                //There are 2 data in the my sql so the ? is 2
                PreparedStatement Add = Con.prepareStatement("Insert into month_tab values (?,?)");
                
                Add.setInt(1,MId);
                //Add.setString(2,ElectionNameTb.getText());
                //Add.setString(3, EDate);
                Add.setString(2,m);
                int row = Add.executeUpdate();
                JOptionPane.showMessageDialog(this, "Month Successfuly added");
                //closing the connection
                Con.close();
                MonthDisplay();
                
            }catch (Exception e){
                JOptionPane.showMessageDialog(this, e);
                
            }
        }
    }//GEN-LAST:event_AddMonthMouseClicked

    int n = -1;
    private void MonthtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MonthtableMouseClicked
        //when you click the event of the election, the name will be filled with
        //the event name that you clicked.
        DefaultTableModel model = (DefaultTableModel)Monthtable.getModel();
        int Index = Monthtable.getSelectedRow();
        //index 0 is the MonthId
        n = Integer.valueOf(model.getValueAt(Index,0).toString());
        MonthLabel.setText(model.getValueAt(Index, 1).toString());
        
    }//GEN-LAST:event_MonthtableMouseClicked

    private void DeleteMonthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteMonthMouseClicked
        if(n == -1){
            //If none of the option is clicked
            JOptionPane.showMessageDialog(this, " Which one you want to delete? ");
            
        }else{
            try{
                //connection
                Con=DriverManager.getConnection(url,user,pass);
                String Q = " Delete from month_tab where MId = "+n;
                Statement Delt = Con.createStatement();
                Delt.executeUpdate(Q);
                //When the statement is executed, it'll show Month is deleted.
                JOptionPane.showMessageDialog(this,"Month is deleted! ");
                MonthDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this,e);
            }
        }
    }//GEN-LAST:event_DeleteMonthMouseClicked

    private void EditMonthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditMonthMouseClicked
        if(n == -1 || String.valueOf(VARMONTH.getMonth()).toString().isEmpty()){
            JOptionPane.showMessageDialog(this, " Missing information ");
            
        }else{
            try{
                //Month
                String Month = String.valueOf(VARMONTH.getMonth()+1);
                MonthString();
                //connecting to the month-tab and updating it by using UpdateQuery
                Con=DriverManager.getConnection(url,user,pass);
                String Q = "Update month_tab set MD=? where MId=? ";
                PreparedStatement UpdateQuery = Con.prepareStatement(Q);
                UpdateQuery.setString(1, m);
                UpdateQuery.setInt(2, n);
                UpdateQuery.executeUpdate();
                //Indicate if the month is edited
                JOptionPane.showMessageDialog(this,"The Month is edited! ");
                //Dipslaying the updated table
                MonthDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this,e);
            }
        }
    }//GEN-LAST:event_EditMonthMouseClicked

    private void BackMonthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackMonthMouseClicked
        //The Back Button will redirect you to the MainPage.
        new MainPage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackMonthMouseClicked

 
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Thirdpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddMonth;
    private javax.swing.JButton BackMonth;
    private javax.swing.JButton DeleteMonth;
    private javax.swing.JButton EditMonth;
    private javax.swing.JLabel MonthLabel;
    private javax.swing.JTable Monthtable;
    private com.toedter.calendar.JMonthChooser VARMONTH;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
