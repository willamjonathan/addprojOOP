package main.java.VoteManagementSys;

//for connection to sql purposes
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
//for picture
import javax.swing.ImageIcon;
import java.awt.Image;
//for message
import javax.swing.JOptionPane;
//for table manipulation
import net.proteanit.sql.DbUtils; 
import javax.swing.table.DefaultTableModel;


public class Sixthpage extends javax.swing.JFrame {
    //copied from pages before.
    Connection Con = null;
    PreparedStatement pst = null;
    ResultSet Rs = null;
    Statement St = null;
    
    String url = "jdbc:mysql://localhost:3306/oopdb";
    String user = "root";
    String pass = "";
    
    int n = -1;
    int Id2;
    
    public Sixthpage() {
        initComponents();
        SDisplay();
        textnoted.setVisible(false);
    }
    //overloading operator
    int SixthID; 
    public Sixthpage (int theId){
        initComponents();
        SDisplay();
        textnoted.setVisible(false);
        SixthID = theId;
        JOptionPane.showMessageDialog(this,SixthID);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableS = new javax.swing.JTable();
        SupportButton = new javax.swing.JButton();
        ButtonSB = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        EMPNAME = new javax.swing.JLabel();
        EMPPHOTO = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textnoted = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 196, 200));

        jPanel2.setBackground(new java.awt.Color(75, 134, 115));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("BEM SYSTEM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setText("Who is the best employee?");

        TableS.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TableS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TableS.setRowHeight(30);
        TableS.setSelectionBackground(new java.awt.Color(75, 134, 115));
        TableS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableS);

        SupportButton.setBackground(new java.awt.Color(153, 153, 153));
        SupportButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SupportButton.setText("Support");
        SupportButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SupportButtonMouseClicked(evt);
            }
        });
        SupportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupportButtonActionPerformed(evt);
            }
        });

        ButtonSB.setBackground(new java.awt.Color(104, 167, 173));
        ButtonSB.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ButtonSB.setText("Back");
        ButtonSB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonSBMouseClicked(evt);
            }
        });
        ButtonSB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSBActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel5.setText("Employee's profile");

        EMPNAME.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        EMPNAME.setText("Name: ");

        EMPPHOTO.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        EMPPHOTO.setText("Photo");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("List");

        textnoted.setFont(new java.awt.Font("Square721 Cn BT", 0, 18)); // NOI18N
        textnoted.setForeground(new java.awt.Color(153, 153, 153));
        textnoted.setText("Supported!");

        jPanel3.setBackground(new java.awt.Color(75, 134, 115));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(182, 182, 182))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EMPNAME)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(SupportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textnoted, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(EMPPHOTO, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ButtonSB)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(EMPPHOTO, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(EMPNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textnoted, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SupportButton, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE))))
                .addGap(27, 27, 27)
                .addComponent(ButtonSB)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 28, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void SupportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupportButtonActionPerformed

    }//GEN-LAST:event_SupportButtonActionPerformed

    private void ButtonSBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSBActionPerformed

    }//GEN-LAST:event_ButtonSBActionPerformed
    
    //To make sure the photo is not too big, or equals to the decided size in the JFrame
    private ImageIcon SizingPict( String ImagePath, byte [] pic){
        ImageIcon EmpImage = null;
        if(ImagePath != null){
            EmpImage = new ImageIcon(ImagePath);
        }else{
            EmpImage = new ImageIcon(pic);
        }
        Image img = EmpImage.getImage();
        //Scaling it with the size of the JFrame EMPPICT
        Image newImg = img.getScaledInstance(EMPPHOTO.getWidth(), EMPPHOTO.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
    
    private void SDisplay(){
        try{
            //displaying function to the table
            //connection from emp_tab in mysql 
            Con = DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            Rs = St.executeQuery("Select * from emp_tab");
            TableS.setModel(DbUtils.resultSetToTableModel(Rs));
        }catch(Exception ex){
            
        }
    }
    
    private void PhotoDisplay()
    {
    //function to display photo
    //Getting the Photo from the employee tab
    String Q = "Select EmpPhoto from emp_tab where EmpId="+n ;
    Statement St;
    ResultSet Rs;
    
    try{
        //connecting to the sql first and to the emp_tab
        Con = DriverManager.getConnection(url,user,pass);
        St = Con.createStatement();
        Rs = St.executeQuery(Q);
        if(Rs.next()){
            EMPPHOTO.setIcon(SizingPict(null,Rs.getBytes("EmpPhoto")));
            
        }
    }catch(Exception e){
        
    }
    }
    
    int check;
    private void Once(){
        //function that is used so that the same user can't vote twice
        try{
            St1 = Con.createStatement();
            Rs1 = St.executeQuery("select * from result_tab where VisId="+
                    SixthID+" and MId="+Id2+" ");
        //if function that set up int check to 1 or 0; 1 is for ppl that has voted once.
            if(Rs1.next()){check = 1;}else{check = 0;}
        }catch(Exception EX){
            JOptionPane.showMessageDialog(this,EX);
        }
    }

    private void TableSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableSMouseClicked
        //when the table is clicked, it will : 
        DefaultTableModel model = (DefaultTableModel)TableS.getModel();
        //get the value at the selected row and filling the information in the space available
        int Index = TableS.getSelectedRow();
        n = Integer.valueOf(model.getValueAt(Index,0).toString());
        //changin name variable in JFrame to the name of the applicant ( name label)
        EMPNAME.setText(model.getValueAt(Index,1).toString());
        Id2 = Integer.valueOf(model.getValueAt(Index, 5).toString());//what month user chose
        
        PhotoDisplay();
    }//GEN-LAST:event_TableSMouseClicked
    int RId ;
    Statement St1 = null;
    ResultSet Rs1 = null;
    //same function with CalculateMonthID
    private void CalculateResultID()
    {
      try{
          //connecitng to result tab and taking the max RId value
          St1 = Con.createStatement();
          Rs1 = St1.executeQuery("Select MAX(RId) from result_tab");
          Rs1.next();
          //Getting the max and add it with 1
          RId = Rs1.getInt(1)+1;
          
      }catch(Exception Ex){  
      }
    }

    private void SupportButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SupportButtonMouseClicked
        //calling the Once function to make sure 1 person = 1 vote.
        Once();
        if(n == -1){
            //if the button isn't click.
            JOptionPane.showMessageDialog(this,"Vote!!!");
        }else if(check>0)
        {
            //if you have voted once check = 1; if it is >0 you haven't voted
            JOptionPane.showMessageDialog(this, "You have voted before!");
        }else{
            try{
                //Counting the RId function
                CalculateResultID();
                //connecting to the result_tab in mysql and inserting 4 values.
                Con=DriverManager.getConnection(url,user,pass);
                
                PreparedStatement Add = Con.prepareStatement("Insert into result_tab values (?,?,?,?)");
                //setting up the values
                Add.setInt(1,RId);
                Add.setInt(2,SixthID);//VisId
                Add.setInt(3,Id2);//Basically this becomes the MId
                Add.setInt(4,n);//EmpId
                
                int row = Add.executeUpdate();
                JOptionPane.showMessageDialog(this, "Voted!");
                //closing the connection
                Con.close();
                //SUPPORT text will be visible once you click the support button
                textnoted.setVisible(true);
                SDisplay();//updating the display
                //meanwhile the support button will be gone
                SupportButton.setVisible(false);
                
            }catch (Exception e){
                JOptionPane.showMessageDialog(this, e);
                
            }
        }
    }//GEN-LAST:event_SupportButtonMouseClicked
    //button support back
    private void ButtonSBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonSBMouseClicked
        //redirecting you to the secondpage
        new Secondpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ButtonSBMouseClicked


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sixthpage().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonSB;
    private javax.swing.JLabel EMPNAME;
    private javax.swing.JLabel EMPPHOTO;
    private javax.swing.JButton SupportButton;
    private javax.swing.JTable TableS;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel textnoted;
    // End of variables declaration//GEN-END:variables
}
