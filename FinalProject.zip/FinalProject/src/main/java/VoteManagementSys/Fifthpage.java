package main.java.VoteManagementSys;
//For connection purposes
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
//For showing message
import javax.swing.JOptionPane;
//For table manipulation
import net.proteanit.sql.DbUtils; 
import javax.swing.table.DefaultTableModel;


public class Fifthpage extends javax.swing.JFrame {
    //Copied code from pages before.
    Connection Con = null;
    PreparedStatement pst = null;
    ResultSet Rs = null;
    Statement St = null;
    
    String url = "jdbc:mysql://localhost:3306/oopdb";
    String user = "root";
    String pass = "";
    
    public Fifthpage() {
        //initializing the component
        initComponents();
        //calling functions
        GetChooseOption();
        VisDisplay();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        VISNAME = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        VisitorTable = new javax.swing.JTable();
        VISADD = new javax.swing.JButton();
        VISDELETE = new javax.swing.JButton();
        VISEDIT = new javax.swing.JButton();
        VISBACK = new javax.swing.JButton();
        VISAGE = new javax.swing.JTextField();
        VISGENDER = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        VISCHOOSE = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        VISPASS = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 196, 200));

        jPanel2.setBackground(new java.awt.Color(75, 134, 115));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("BEM SYSTEM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setText("Create Visitor Account");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Age : ");

        VISNAME.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        VISNAME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISNAMEActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Name : ");

        VisitorTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        VisitorTable.setRowHeight(25);
        VisitorTable.setSelectionBackground(new java.awt.Color(75, 134, 115));
        VisitorTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VisitorTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(VisitorTable);

        VISADD.setBackground(new java.awt.Color(104, 167, 173));
        VISADD.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VISADD.setText("Add");
        VISADD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VISADDMouseClicked(evt);
            }
        });
        VISADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISADDActionPerformed(evt);
            }
        });

        VISDELETE.setBackground(new java.awt.Color(104, 167, 173));
        VISDELETE.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VISDELETE.setText("Delete");
        VISDELETE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VISDELETEMouseClicked(evt);
            }
        });
        VISDELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISDELETEActionPerformed(evt);
            }
        });

        VISEDIT.setBackground(new java.awt.Color(104, 167, 173));
        VISEDIT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VISEDIT.setText("Edit");
        VISEDIT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VISEDITMouseClicked(evt);
            }
        });
        VISEDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISEDITActionPerformed(evt);
            }
        });

        VISBACK.setBackground(new java.awt.Color(104, 167, 173));
        VISBACK.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VISBACK.setText("Back");
        VISBACK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VISBACKMouseClicked(evt);
            }
        });
        VISBACK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISBACKActionPerformed(evt);
            }
        });

        VISAGE.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        VISAGE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISAGEActionPerformed(evt);
            }
        });

        VISGENDER.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        VISGENDER.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        VISGENDER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISGENDERActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Gender : ");

        VISCHOOSE.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        VISCHOOSE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISCHOOSEActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Password : ");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Choose:");

        VISPASS.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        VISPASS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VISPASSActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(75, 134, 115));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(VISNAME)
                                            .addComponent(VISCHOOSE, 0, 138, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(VISAGE)
                                            .addComponent(VISGENDER, 0, 138, Short.MAX_VALUE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel4)
                                                    .addComponent(jLabel8))
                                                .addGap(90, 90, 90)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel3)
                                                    .addComponent(jLabel6)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(VISBACK, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(VISADD, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(29, 29, 29)
                                                .addComponent(VISDELETE, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(VISEDIT, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(0, 35, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(VISPASS, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60))))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(VISNAME, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(VISAGE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(VISCHOOSE, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(VISGENDER, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(VISPASS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(VISADD)
                            .addComponent(VISDELETE)
                            .addComponent(VISEDIT))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(VISBACK)
                        .addGap(25, 25, 25)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void VISNAMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISNAMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISNAMEActionPerformed

    private void VISADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISADDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISADDActionPerformed

    private void VISDELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISDELETEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISDELETEActionPerformed

    private void VISEDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISEDITActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISEDITActionPerformed

    private void VISBACKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISBACKActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISBACKActionPerformed

    private void VISAGEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISAGEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISAGEActionPerformed

    private void VISGENDERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISGENDERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISGENDERActionPerformed

    private void VISCHOOSEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISCHOOSEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISCHOOSEActionPerformed

    private void VISPASSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VISPASSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VISPASSActionPerformed
    private void GetChooseOption(){
        try{
            //Connecting it with the thirdpage data
            //The month data is there; it will be on the Choose part in fourpage.
            Con=DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            String Q = "Select * from month_tab";
            Rs = St.executeQuery(Q);
            //rs.next moves cursor forward from its current position
            while(Rs.next())
            {
                String MId2 = Rs.getString("MId");
                VISCHOOSE.addItem(MId2);
                
            }
        }catch(Exception e){
            
        }
    }

    int VisId ;
    Statement St1;
    ResultSet Rs1;
    //Same function with CalculateMonthID
    private void CalculateVisID()
    {
      try{
          St1 = Con.createStatement();
          Rs1 = St1.executeQuery("Select MAX(VisId) from vis_tab");
          Rs1.next();
          VisId = Rs1.getInt(1)+1;
          
          
      }catch(Exception Ex){  
      }
    }
    //function that is used to display in table
    private void VisDisplay(){
        try{
            //creating connection from vis_tab in my sql
            Con = DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            Rs = St.executeQuery("Select * from vis_tab");
            VisitorTable.setModel(DbUtils.resultSetToTableModel(Rs));
        }catch(Exception ex){
            
        }
    }
    private void VISADDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VISADDMouseClicked
        if(VISAGE.getText().isEmpty()|| VISNAME.getText().isEmpty()||
           VISCHOOSE.getSelectedIndex() == -1||VISGENDER.getSelectedIndex()== -1 ){
            //if there's unfilled thing, it will show "information incomplete"
            JOptionPane.showMessageDialog(this, "Information incomplete!");
        }else{
            try{
            //calling the calculate VisID to update the VisId
            CalculateVisID();
            Con=DriverManager.getConnection(url,user,pass);
            //connecting data with mysql; connecting with the vis_tab and inserting to 6 values
            PreparedStatement Add = Con.prepareStatement("insert into vis_tab values (?,?,?,?,?,?)");
            //adding the values
            Add.setInt(1,VisId);
            Add.setString(2, VISNAME.getText());
            Add.setInt(3, Integer.valueOf(VISAGE.getText()));
            Add.setString(4, VISPASS.getText());
            Add.setString(5, VISGENDER.getSelectedItem().toString());
            Add.setInt(6, Integer.valueOf(VISCHOOSE.getSelectedItem().toString()));
            
            int row = Add.executeUpdate();
            //Pop up message to tell you when add is successfully done
            JOptionPane.showMessageDialog(this, "Visitor account is created!");
            Con.close();
            //Updating the display
            VisDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }
        }
                           
    }//GEN-LAST:event_VISADDMouseClicked
    int n = -1;
    private void VISDELETEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VISDELETEMouseClicked
        if(n == -1){
            //you have to select if you don't want to be popped up by this question
            JOptionPane.showMessageDialog(this, " Which one you want to delete? ");
            
        }else{
            try{
                //connecting with the sql
                Con=DriverManager.getConnection(url,user,pass);
                //you have to select first before being able to delete
                String Q = " Delete from vis_tab where VisId = "+n;
                Statement Delt = Con.createStatement();
                Delt.executeUpdate(Q);//executing the delete statement
                JOptionPane.showMessageDialog(this,"Visitor information is deleted! ");
                //displaying the information again ,p.s. already updated.
                VisDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this,e);
            }
        }
    }//GEN-LAST:event_VISDELETEMouseClicked

    private void VisitorTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VisitorTableMouseClicked
        //when the visitor table is clicked
        DefaultTableModel model = (DefaultTableModel)VisitorTable.getModel();
        //assigning index as the clicked part
        int Index = VisitorTable.getSelectedRow();
        //setting up; so when it is clicked, the infos are filled in the name area,age,etc.
        n = Integer.valueOf(model.getValueAt(Index,0).toString());
        VISNAME.setText(model.getValueAt(Index, 1).toString());
        VISAGE.setText(model.getValueAt(Index, 2).toString());
        VISPASS.setText(model.getValueAt(Index, 3).toString());
        VISGENDER.setSelectedItem(model.getValueAt(Index, 4).toString());
        VISCHOOSE.setSelectedItem(model.getValueAt(Index,5).toString());
        //calling the display function to display
        VisDisplay();
    }//GEN-LAST:event_VisitorTableMouseClicked

    private void VISEDITMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VISEDITMouseClicked
      if(VISAGE.getText().isEmpty()|| VISNAME.getText().isEmpty()||
           VISCHOOSE.getSelectedIndex() == -1||VISGENDER.getSelectedIndex()== -1 ){
          //by not selecting row at table, missing info will pop!
          JOptionPane.showMessageDialog(this, " Missing information ");
            
        }else{
            try{
                //First you have to select the one you want to edit by clicking onto the table
                //Connecting to the vis_tab in my sql and setting the VisName,etc.
                Con=DriverManager.getConnection(url,user,pass);
                String Query = " Update vis_tab set VisName=?,VisAge=?, VisPass=?,VisGen=?,VisChoose=? where VisId=?";
                PreparedStatement UpdateQuery = Con.prepareStatement(Query);
                //Setting the new information
                UpdateQuery.setString(1, VISNAME.getText());
                UpdateQuery.setInt(2, Integer.valueOf(VISAGE.getText()) );
                UpdateQuery.setString(3, VISPASS.getText());
                UpdateQuery.setString(4, VISGENDER.getSelectedItem().toString());
                UpdateQuery.setInt(5, Integer.valueOf(VISCHOOSE.getSelectedItem().toString()));
                UpdateQuery.setInt(6,n);
                UpdateQuery.executeUpdate();
                //Pop up message shown when edit is done
                JOptionPane.showMessageDialog(this,"Customer account is edited! ");
                VisDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this,e);
            }
        }
    }//GEN-LAST:event_VISEDITMouseClicked

    private void VISBACKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VISBACKMouseClicked
        //the back button will redirect you to the mainpage.
        new MainPage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_VISBACKMouseClicked

    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Fifthpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton VISADD;
    private javax.swing.JTextField VISAGE;
    private javax.swing.JButton VISBACK;
    private javax.swing.JComboBox<String> VISCHOOSE;
    private javax.swing.JButton VISDELETE;
    private javax.swing.JButton VISEDIT;
    private javax.swing.JComboBox<String> VISGENDER;
    private javax.swing.JTextField VISNAME;
    private javax.swing.JTextField VISPASS;
    private javax.swing.JTable VisitorTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
