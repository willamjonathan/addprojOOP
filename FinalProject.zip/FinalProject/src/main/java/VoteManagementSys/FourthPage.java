package main.java.VoteManagementSys;

//Connection purposes
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
//For message
import javax.swing.JOptionPane;
//For picture uploading
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.swing.JFileChooser;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileNameExtensionFilter;
/*To be able to use DbUtils
To use (net) u should include Rs2Xml file first. 
This is then use to manipulate table
"www.youtube.com/watch?v=4nvTwvfWt7I"
*/
import net.proteanit.sql.DbUtils; 
import javax.swing.table.DefaultTableModel;

public class FourthPage extends javax.swing.JFrame {
    //Copied from page before
    Connection Con = null;
    PreparedStatement pst = null;
    ResultSet Rs = null;
    Statement St = null;
    
    String url = "jdbc:mysql://localhost:3306/oopdb";
    String user = "root";
    String pass = "";
    

    public FourthPage() {
        initComponents();
        GetChooseOption();
        EmployeeDisplay();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ElectionsAP = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        EMPNAME = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        EmpTable = new javax.swing.JTable();
        EMPADD = new javax.swing.JButton();
        EMPDELETE = new javax.swing.JButton();
        EMPEDIT = new javax.swing.JButton();
        EMPBACK = new javax.swing.JButton();
        EMPAGE = new javax.swing.JTextField();
        EMPGENDER = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        EMPCHOOSE = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        EMPPICT = new javax.swing.JLabel();
        EMPSEARCH = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        ElectionsAP.setBackground(new java.awt.Color(153, 196, 200));

        jPanel2.setBackground(new java.awt.Color(75, 134, 115));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("BEM SYSTEM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(734, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setText("Employee Data");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Age : ");

        EMPNAME.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EMPNAME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPNAMEActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Name : ");

        EmpTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EmpTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Gender", "Photo", "Elections"
            }
        ));
        EmpTable.setRowHeight(25);
        EmpTable.setSelectionBackground(new java.awt.Color(75, 134, 115));
        EmpTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EmpTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(EmpTable);

        EMPADD.setBackground(new java.awt.Color(104, 167, 173));
        EMPADD.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EMPADD.setText("Add");
        EMPADD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EMPADDMouseClicked(evt);
            }
        });
        EMPADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPADDActionPerformed(evt);
            }
        });

        EMPDELETE.setBackground(new java.awt.Color(104, 167, 173));
        EMPDELETE.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EMPDELETE.setText("Delete");
        EMPDELETE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EMPDELETEMouseClicked(evt);
            }
        });
        EMPDELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPDELETEActionPerformed(evt);
            }
        });

        EMPEDIT.setBackground(new java.awt.Color(104, 167, 173));
        EMPEDIT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EMPEDIT.setText("Edit");
        EMPEDIT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EMPEDITMouseClicked(evt);
            }
        });
        EMPEDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPEDITActionPerformed(evt);
            }
        });

        EMPBACK.setBackground(new java.awt.Color(104, 167, 173));
        EMPBACK.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EMPBACK.setText("Back");
        EMPBACK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EMPBACKMouseClicked(evt);
            }
        });
        EMPBACK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPBACKActionPerformed(evt);
            }
        });

        EMPAGE.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EMPAGE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPAGEActionPerformed(evt);
            }
        });

        EMPGENDER.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EMPGENDER.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        EMPGENDER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPGENDERActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Photo");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Gender : ");

        EMPCHOOSE.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EMPCHOOSE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPCHOOSEActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Month:");

        EMPPICT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N

        EMPSEARCH.setBackground(new java.awt.Color(104, 167, 173));
        EMPSEARCH.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EMPSEARCH.setText("Search");
        EMPSEARCH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EMPSEARCHMouseClicked(evt);
            }
        });
        EMPSEARCH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EMPSEARCHActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(75, 134, 115));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout ElectionsAPLayout = new javax.swing.GroupLayout(ElectionsAP);
        ElectionsAP.setLayout(ElectionsAPLayout);
        ElectionsAPLayout.setHorizontalGroup(
            ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(ElectionsAPLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ElectionsAPLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel2)
                        .addContainerGap(746, Short.MAX_VALUE))
                    .addGroup(ElectionsAPLayout.createSequentialGroup()
                        .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ElectionsAPLayout.createSequentialGroup()
                                .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(EMPNAME, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                                    .addComponent(EMPCHOOSE, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                                .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(EMPAGE, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                                    .addComponent(EMPGENDER, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(ElectionsAPLayout.createSequentialGroup()
                                .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(ElectionsAPLayout.createSequentialGroup()
                                            .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel7)
                                                .addComponent(jLabel4))
                                            .addGap(90, 90, 90)
                                            .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel3)
                                                .addComponent(jLabel6)))
                                        .addComponent(EMPSEARCH, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(ElectionsAPLayout.createSequentialGroup()
                                            .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(EMPBACK, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(EMPADD, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGap(18, 18, 18)
                                            .addComponent(EMPDELETE)
                                            .addGap(18, 18, 18)
                                            .addComponent(EMPEDIT))
                                        .addComponent(EMPPICT, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel5))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48))))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        ElectionsAPLayout.setVerticalGroup(
            ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ElectionsAPLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ElectionsAPLayout.createSequentialGroup()
                        .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ElectionsAPLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ElectionsAPLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(EMPNAME, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EMPAGE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(EMPCHOOSE, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EMPGENDER, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(EMPPICT, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(EMPSEARCH)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(ElectionsAPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(EMPADD)
                            .addComponent(EMPDELETE)
                            .addComponent(EMPEDIT))
                        .addGap(18, 18, 18)
                        .addComponent(EMPBACK)
                        .addGap(19, 19, 19))
                    .addGroup(ElectionsAPLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ElectionsAP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ElectionsAP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void EMPNAMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPNAMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPNAMEActionPerformed

    private void EMPADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPADDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPADDActionPerformed

    private void EMPDELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPDELETEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPDELETEActionPerformed

    private void EMPEDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPEDITActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPEDITActionPerformed

    private void EMPBACKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPBACKActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPBACKActionPerformed

    private void EMPAGEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPAGEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPAGEActionPerformed

    private void EMPGENDERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPGENDERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPGENDERActionPerformed

    private void EMPCHOOSEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPCHOOSEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPCHOOSEActionPerformed

    private void EMPSEARCHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EMPSEARCHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EMPSEARCHActionPerformed
    
    int EmpId = 0;
    Statement St1;
    ResultSet Rs1;
    //Same function with the CalculateMonthID
    private void CalculateEmpID()
    {
      try{
          St1 = Con.createStatement();
          Rs1 = St1.executeQuery("Select MAX(EmpId) from emp_tab");
          Rs1.next();
          EmpId = Rs1.getInt(1)+1; // getint(1) is the row of the table. 
          
          
      }catch(Exception Ex){  
      }
    }
    
    //to search for picture in your computer
    String imgpath = null;
    private void EMPSEARCHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EMPSEARCHMouseClicked
        JFileChooser chooser = new JFileChooser();
        //Setting the current directory to user.home
        //user.home contains the comp personal files
        chooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        //To make sure that only photos are able to be added; not other type of files, i.e. docs,etc.
        FileNameExtensionFilter filter = new FileNameExtensionFilter(" *.Images","gif","pdf","jpg","png");
        chooser.addChoosableFileFilter(filter);
        int result = chooser.showSaveDialog(null);
        if(result == JFileChooser.APPROVE_OPTION){
            File selectedFile = chooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            //Setting the picture whilst sizing it with funct sizingpict.
            EMPPICT.setIcon(SizingPict(path,null));
            imgpath = path;
        }
        
    }//GEN-LAST:event_EMPSEARCHMouseClicked

    private void EMPADDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EMPADDMouseClicked
        if(EMPNAME.getText().isEmpty()|| EMPAGE.getText().isEmpty()||
           EMPCHOOSE.getSelectedIndex() == -1||EMPGENDER.getSelectedIndex()==-1 ){
            JOptionPane.showMessageDialog(this, "Information incomplete!");
        }else{
            try{
            CalculateEmpID();//calling the CalculateEmpID for updating EmpId
            //Connecting to mysql
            Con=DriverManager.getConnection(url,user,pass);
            //accessing the emp_tab in mysql ; there are 6 variables in emp_tab
            PreparedStatement Add = Con.prepareStatement("insert into emp_tab values (?,?,?,?,?,?)");
            //the setting of the table
            Add.setInt(1,EmpId);
            Add.setString(2, EMPNAME.getText());
            Add.setInt(3, Integer.valueOf(EMPAGE.getText()));
            Add.setString(4, EMPGENDER.getSelectedItem().toString());
            InputStream img = new FileInputStream(imgpath);
            Add.setBlob(5, img);
            Add.setInt(6, Integer.valueOf(EMPCHOOSE.getSelectedItem().toString()));
            //executing the new table data
            int row = Add.executeUpdate();
            JOptionPane.showMessageDialog(this, "Employee is registered!");
            Con.close();
            //Calling the employee display, to update when add is clicked.
            EmployeeDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }
        }
    }//GEN-LAST:event_EMPADDMouseClicked
    //To make sure the photo is not too big, or equals to the decided size in the JFrame
    private ImageIcon SizingPict( String ImagePath, byte [] pic){
        ImageIcon EmpImage = null;
        if(ImagePath != null){
            EmpImage = new ImageIcon(ImagePath);
        }else{
            EmpImage = new ImageIcon(pic);
        }
        Image img = EmpImage.getImage();
        //Scaling it with the size of the JFrame EMPPICT
        Image newImg = img.getScaledInstance(EMPPICT.getWidth(), EMPPICT.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
    //function that display the picture
    private void PhotoDisplay()
    {
    String Q = "Select EmpPhoto from emp_tab where EmpId="+n ;
    Statement St;
    ResultSet Rs;
    
    try{
        Con = DriverManager.getConnection(url,user,pass);
        St = Con.createStatement();
        Rs = St.executeQuery(Q);
        if(Rs.next()){
            EMPPICT.setIcon(SizingPict(null,Rs.getBytes("EmpPhoto")));
            
        }
    }catch(Exception e){   
    }
    }
    //Display function, to display employee data to the table
    private void EmployeeDisplay(){
        try{
            //connecting to the sql
            Con = DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            //accessing the emp_table in mysql 
            Rs = St.executeQuery("Select * from emp_tab");
            //setting the data to table model
            EmpTable.setModel(DbUtils.resultSetToTableModel(Rs));
        }catch(Exception ex){
            
        }
    }
    int n = -1;
    private void EmpTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmpTableMouseClicked
        DefaultTableModel model = (DefaultTableModel)EmpTable.getModel();
        //When you click the table in employee page, these info will be shown
        int Index = EmpTable.getSelectedRow();
        n = Integer.valueOf(model.getValueAt(Index,0).toString());
        EMPNAME.setText(model.getValueAt(Index, 1).toString());
        EMPAGE.setText(model.getValueAt(Index, 2).toString());
        EMPGENDER.setSelectedItem(model.getValueAt(Index, 3).toString());
        EMPCHOOSE.setSelectedItem(model.getValueAt(Index,5).toString());
        PhotoDisplay();
        
    }//GEN-LAST:event_EmpTableMouseClicked
    private void GetChooseOption(){
        try{
            //Connecting it with the thirdpage data
            //The month data is there; it will be on the Choose part in fourpage.
            Con=DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            String Q = "Select * from month_tab";
            Rs = St.executeQuery(Q);
            while(Rs.next())
            {
                String MId2 = Rs.getString("MId");
                EMPCHOOSE.addItem(MId2);
                
            }
        }catch(Exception e){
            
        }
    }
    private void EMPDELETEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EMPDELETEMouseClicked
        if(n == -1){
            //if none from the table is clicked n = -1
            JOptionPane.showMessageDialog(this, " Which one you want to delete? ");
            
        }else{
            try{
                Con=DriverManager.getConnection(url,user,pass);
                String Q = " Delete from emp_tab where EmpId = "+n;
                Statement Delt = Con.createStatement();
                //The delete execution; deleting the data from the sql 
                Delt.executeUpdate(Q);
                JOptionPane.showMessageDialog(this,"Election is deleted! ");
                EmployeeDisplay();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this,e);
            }
        }
    }//GEN-LAST:event_EMPDELETEMouseClicked

    private void EMPEDITMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EMPEDITMouseClicked
       
        if (imgpath !=null){
            try{
                //overwrite the img with new file
                InputStream img = new FileInputStream(imgpath);
                
                Con=DriverManager.getConnection(url,user,pass);
                String Q = " Update emp_tab set EmpName=?,EmpAge=?,EmpGen=?,EmpPhoto=?,EmpChoose=? where EmpId=?";
                PreparedStatement UpdateQuery = Con.prepareStatement(Q);
                UpdateQuery.setString(1, EMPNAME.getText());
                UpdateQuery.setInt(2, Integer.valueOf(EMPAGE.getText().toString()));
                UpdateQuery.setString(3, EMPGENDER.getSelectedItem().toString());
                UpdateQuery.setBlob(4, img);
                UpdateQuery.setString(5, EMPCHOOSE.getSelectedItem().toString());
                UpdateQuery.setInt(6,n);
                UpdateQuery.executeUpdate();
                if(UpdateQuery.executeUpdate() ==1){
                JOptionPane.showMessageDialog(this,"Employee is edited! ");
                //To update the table visual
                EmployeeDisplay();
                }else{
                    //if some of the info is not filled
                    JOptionPane.showMessageDialog(this,"Information incomplete!");
                }
            }catch(Exception e){
                JOptionPane.showMessageDialog(this,e);
            }
        }else{
            JOptionPane.showMessageDialog(this,"Select the photo!");
            EMPPICT.setIcon(null);
            EMPPICT.setText("");
        }
    }//GEN-LAST:event_EMPEDITMouseClicked

    private void EMPBACKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EMPBACKMouseClicked
        //The back button will redirect you to the MainPage
        new MainPage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EMPBACKMouseClicked

    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FourthPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EMPADD;
    private javax.swing.JTextField EMPAGE;
    private javax.swing.JButton EMPBACK;
    private javax.swing.JComboBox<String> EMPCHOOSE;
    private javax.swing.JButton EMPDELETE;
    private javax.swing.JButton EMPEDIT;
    private javax.swing.JComboBox<String> EMPGENDER;
    private javax.swing.JTextField EMPNAME;
    private javax.swing.JLabel EMPPICT;
    private javax.swing.JButton EMPSEARCH;
    private javax.swing.JPanel ElectionsAP;
    private javax.swing.JTable EmpTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
