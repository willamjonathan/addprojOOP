package main.java.VoteManagementSys;


//For connection purposes
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
//For showing message
import javax.swing.JOptionPane;
//For displaying image
import javax.swing.ImageIcon;
import java.awt.Image;
//For manipulating table
import net.proteanit.sql.DbUtils; 
import javax.swing.table.DefaultTableModel;
//For Percentage
import java.text.DecimalFormat;

public class Seventhpage extends javax.swing.JFrame {
    //Copied from pages before
    Connection Con = null;
    PreparedStatement pst = null;
    ResultSet Rs = null;
    Statement St = null;
    
    String url = "jdbc:mysql://localhost:3306/oopdb";
    String user = "root";
    String pass = "";
    
    //declared variables
    int Winner;
    int Support;
    int Rate;
    int n;
    int total;

    public Seventhpage() {
        initComponents();
        MonthDisplay();
        GetBestEmployee();

    }

    
    @SuppressWarnings("unchecked")
            
    
    private void GetBestEmployee(){
        try{
            
            Con=DriverManager.getConnection(url,user,pass);
            //String Q = " select EmpId, Count(EmpId) from result_tab where MId="+n
             //       +" Group BY EmpId ORDER BY EmpId DESC LIMIT 1 ";
            //https://stackoverflow.com/questions/12235595/find-most-frequent-value-in-sql-column
            //To get the most frequent value methodS
            String Q = "Select EmpId, COUNT(EmpId) as totalrep from result_tab GROUP BY EmpId ORDER BY totalrep DESC LIMIT 1";
            St = Con.createStatement();
            Rs = St.executeQuery(Q);
            while(Rs.next()){
                Winner = Rs.getInt(1);
                
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
    private ImageIcon SizingPict( String ImagePath, byte [] pic){
        ImageIcon EmpImage = null;
        if(ImagePath != null){
            EmpImage = new ImageIcon(ImagePath);
        }else{
            EmpImage = new ImageIcon(pic);
        }
        Image img = EmpImage.getImage();
        //Scaling it with the size of the JFrame EMPPICT
        Image newImg = img.getScaledInstance(EMPPHOTO.getWidth(), EMPPHOTO.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
    private void WinnerData()
    {
    //The Q is to select photo and name from the emp_tab and the Winner key helps to select the right emp
    String Q = "Select EmpPhoto,EmpName from emp_tab where EmpId="+Winner ;
    Statement St;
    ResultSet Rs;
    
    try{
        //Connecting to the empdata in my sql
        Con = DriverManager.getConnection(url,user,pass);
        St = Con.createStatement();
        Rs = St.executeQuery(Q);
        if(Rs.next()){
            //setting the picture
            EMPPHOTO.setIcon(SizingPict(null,Rs.getBytes("EmpPhoto")));
            //The name of employee will be shown overwriting the label "name" in JFrame
            SEVENTHPAGENAME.setText(Rs.getString("EmpName"));
        }
    }catch(Exception e){
        
    }
    }
    //function that shows the percentage of winning
    private void Rate()
    {
    try{
            //connecting to the result_tab in my sql
            Con=DriverManager.getConnection(url,user,pass);
           
            String Q = " select Count(*) from result_tab where MId = "+
                        n;
            St = Con.createStatement();
            Rs = St.executeQuery(Q);
            while(Rs.next()){
                //getting the total support
                total = Rs.getInt(1);
                double rate;
                //method to calculate percentage
                rate = (Support* 100)/total ;
                //string format
                RateTxt.setText(new DecimalFormat("##.##").format(rate)+"%");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
    private void Calculation()
    {
    try{
            
            Con=DriverManager.getConnection(url,user,pass);
            //Getting the support of the best employee; by counting the empId of the winner
            String Q = " select Count(EmpId) from result_tab where EmpId = "+
                        Winner;
            St = Con.createStatement();
            Rs = St.executeQuery(Q);
            while(Rs.next()){
                
                Support = Rs.getInt(1);
                
                Text2.setText(Support+ " Supports ");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        textvoted = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        MonthTable2 = new javax.swing.JTable();
        BackResult = new javax.swing.JButton();
        Text2 = new javax.swing.JLabel();
        RateTxt = new javax.swing.JLabel();
        SEVENTHPAGENAME = new javax.swing.JLabel();
        EMPPHOTO = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 196, 200));

        jPanel2.setBackground(new java.awt.Color(75, 134, 115));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("BEM SYSTEM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        textvoted.setFont(new java.awt.Font("Square721 Cn BT", 0, 18)); // NOI18N
        textvoted.setForeground(new java.awt.Color(153, 153, 153));
        textvoted.setText("The best employee is: ");

        MonthTable2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        MonthTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        MonthTable2.setRowHeight(30);
        MonthTable2.setSelectionBackground(new java.awt.Color(75, 134, 115));
        MonthTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MonthTable2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(MonthTable2);

        BackResult.setBackground(new java.awt.Color(204, 0, 0));
        BackResult.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BackResult.setText("Log out");
        BackResult.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackResultMouseClicked(evt);
            }
        });
        BackResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackResultActionPerformed(evt);
            }
        });

        Text2.setFont(new java.awt.Font("Square721 Cn BT", 1, 18)); // NOI18N
        Text2.setForeground(new java.awt.Color(153, 153, 153));
        Text2.setText("support");

        RateTxt.setFont(new java.awt.Font("Square721 Cn BT", 1, 18)); // NOI18N
        RateTxt.setForeground(new java.awt.Color(255, 0, 51));
        RateTxt.setText("Rate");

        SEVENTHPAGENAME.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        SEVENTHPAGENAME.setText("name");

        EMPPHOTO.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Month List");

        jPanel3.setBackground(new java.awt.Color(75, 134, 115));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BackResult)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 623, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(EMPPHOTO, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                                .addComponent(textvoted, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(Text2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RateTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SEVENTHPAGENAME, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(41, 41, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textvoted, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SEVENTHPAGENAME, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Text2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(RateTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addComponent(EMPPHOTO, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)))
                .addGap(18, 18, 18)
                .addComponent(BackResult)
                .addGap(28, 28, 28)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void MonthTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MonthTable2MouseClicked
        //if the month table is clicked 
        DefaultTableModel model = (DefaultTableModel)MonthTable2.getModel();
        int Index = MonthTable2.getSelectedRow();
        n = Integer.valueOf(model.getValueAt(Index,0).toString());
        //calling function
        GetBestEmployee();
        WinnerData();
        Calculation();
        Rate();

    }//GEN-LAST:event_MonthTable2MouseClicked

    private void BackResultMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackResultMouseClicked
        //By clicking the back button, it will redirect you to the MainPage
        new Secondpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackResultMouseClicked

    private void BackResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackResultActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BackResultActionPerformed
//Function to display the month
    private void MonthDisplay()
    {
        try{
            Con=DriverManager.getConnection(url,user,pass);
            St = Con.createStatement();
            Rs = St.executeQuery("Select * from month_tab ");
            MonthTable2.setModel(DbUtils.resultSetToTableModel(Rs)); 
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }
    
  
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Seventhpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Seventhpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Seventhpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Seventhpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Seventhpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackResult;
    private javax.swing.JLabel EMPPHOTO;
    private javax.swing.JTable MonthTable2;
    private javax.swing.JLabel RateTxt;
    private javax.swing.JLabel SEVENTHPAGENAME;
    private javax.swing.JLabel Text2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel textvoted;
    // End of variables declaration//GEN-END:variables
}
